﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(AnushaCA.Startup))]
namespace AnushaCA
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
