﻿insert into AspNetRoles values(3,'Staff');
select * from AspNetRoles
select * from AspNetUserRoles
select * from AspNetUsers