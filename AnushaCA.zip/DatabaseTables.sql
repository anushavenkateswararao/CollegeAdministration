 
 
use Training_12DecMumbai 
 
create schema CollegeAdmin
go
--------------------DepartmentTable-------------------------
Create Table CollegeAdmin.Department(
DeptID int primary key not null identity(1,1),
DeptName varchar(20)
)
select * from CollegeAdmin.Department

insert into CollegeAdmin.Department(deptname) values('IT');

--------------------StudentTable-------------------------
create table CollegeAdmin.Student(
StudentID int not null primary key identity(100,1),
StudentName varchar(30),
FatherName varchar(30),
Address varchar(40),
DeptID int Foreign key references ca.Department(DeptID)
)
select * from CollegeAdmin.Student
insert into CollegeAdmin.student(StudentName,Fathername,address,DeptID) values('Ramu','Sri','HYD',4);
--------------------AvailableSeatsTable-------------------------
create table CollegeAdmin.AvlSeats(
seatid int not null primary key identity(100,1),
DeptID int foreign key references ca.Department(DeptID),
TotalSeats int not null,
FilledSeats int not null,
AvailableSeats int not null
)
select * from CollegeAdmin.Student
select * from CollegeAdmin.AvlSeats
select * from CollegeAdmin.Department
insert into CollegeAdmin.AvlSeats(DeptID,TotalSeats,FilledSeats,Availableseats) values(6,120,0,120);

--------------------FeesTable-------------------------
create table CollegeAdmin.Fee(
FeeID int not null primary key identity(12345,1),
Amount money,
Paid money,
Balance money,
StudentID int foreign key references CollegeAdmin.Student(StudentID),
DeptID int Foreign key references CollegeAdmin.Department(DeptID)
)
select * from CollegeAdmin.Fee
select * from CollegeAdmin.Department
select * from CollegeAdmin.Student
insert into CollegeAdmin.Fee(amount,paid,balance,studentID,DeptID) values(75000,65000,10000,104,4);
--------------------AdmissionTable-------------------------
create table CollegeAdmin.Admission(
AdmissionNumber int not null primary key Identity(1000,1),
StudentName varchar(30),
Gender varchar(10),
check (Gender in ('MALE', 'FEMALE','others')),
DOB date,
FatherName varchar(30),
Occupation varchar(20),
Address varchar(40),
PhoneNumber PhoneNumber,
check (PhoneNumber like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
Course varchar(30),
Caste varchar(10),
FeeID int Foreign key references CollegeAdmin.Fee(FeeId),
DOJ date
)

select * from CollegeAdmin.Fee
select * from CollegeAdmin.Admission
select * from CollegeAdmin.student

insert into CollegeAdmin.Admission(StudentName,Gender,DOB,FatherName,
Occupation,Address,PhoneNumber,Course,Caste,FeeID,DOJ)
 values ('Ramu','male','1996/07/19','Sri','Business',
 'HYD','9652523704','B.tech','Raja',12349,'2015/09/08');
--------------------AdmissionTable-------------------------
create table CollegeAdmin.Staff
(
StaffID int not null primary key identity(10,1),
DeptID int Foreign key references CollegeAdmin.Department(DeptID),
StaffName varchar(20),
PhoneNumber PhoneNumber,
Salary int,
Experience decimal,
Subjects varchar(30),
NameOfInstitute varchar(30),
Address varchar(40)
)

select * from CollegeAdmin.Staff
insert into CollegeAdmin.Staff(DeptID,StaffName,PhoneNumber,Salary,Experience,Subjects,NameOfInstitute,Address) 
                       values(4,'GayathriSarman',9639639637,50000,1,'Drawing','VIT','Bhimavaram');
   

